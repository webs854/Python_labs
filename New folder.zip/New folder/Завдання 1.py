# Варіант-17
# Завдання №1

a = int(input("Enter a number a: "))
while a < 1 or a > 100:
    a = int(input("Enter a number a again: "))
b = int(input("Enter a number b: "))
while b < 1 or b > 100:
    b = int(input("Enter a number b again: "))
if a > b:
    x = (2 * a) / (b + 1)
elif a == b:
    x = -455
else:
    x = (b + 5) / a


print(f'Result: {x:1.2f}')
