def common_products(stores):
    common = stores[0]
    for s in stores[1:]:
        common = common & s
    return common


# Кількість магазинів
m = int(input("Введіть кількість магазинів: "))

stores = []

for i in range(m):
    n = int(input(f"\nКількість товарів у магазині {i + 1}: "))
    products = []

    for j in range(n):
        products.append(input(f"Товар {j + 1}: "))

    stores.append(set(products))

# Виклик функції
result = common_products(stores)

# Вивід
print("\nТовари, які є в усіх магазинах:", result)
