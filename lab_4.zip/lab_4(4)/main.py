def find_neighbors(lst, element):
    if element not in lst:
        print("Елемент не знайдено у списку")
        return

    index = lst.index(element)

    if index == 0 or index == len(lst) - 1:
        print("Елемент знаходиться на краю списку")
        return

    print("Лівий елемент:", lst[index - 1])
    print("Правий елемент:", lst[index + 1])


# Ввід списку
n = int(input("Введіть кількість елементів списку: "))
lst = []

for i in range(n):
    lst.append(input(f"Елемент {i + 1}: "))

# Ввід елемента
element = input("Введіть елемент для пошуку: ")

# Виклик функції
find_neighbors(lst, element)
