def extend_with_odd_index_elements(lst):
    odd_elements = []
    for i in range(len(lst)):
        if i % 2 == 1:
            odd_elements.append(lst[i])
    lst.extend(odd_elements)
    return lst


# Ввід списку
n = int(input("Введіть кількість елементів списку: "))
lst = []

for i in range(n):
    lst.append(input(f"Елемент {i + 1}: "))

# Виклик функції
result = extend_with_odd_index_elements(lst)

# Вивід
print("Результуючий список:", result)
