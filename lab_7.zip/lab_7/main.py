import string

def Open(file_name, mode):
    try:
        file = open(file_name, mode, encoding="utf-8")
    except:
        print("File", file_name, "wasn't opened!")
        return None
    else:
        print("File", file_name, "was opened!")
        return file


file1_name = "TF20_1.txt"
file2_name = "TF20_2.txt"

# КРОК 1: створення і запис у TF20_1
file_1_w = Open(file1_name, "w")

if file_1_w != None:
    file_1_w.write("Python is a powerful programming language.\n")
    file_1_w.write("Working with files is very interesting and useful!\n")
    file_1_w.write("Text processing in Python is simple, clear, and practical.")
    file_1_w.close()
    print("File TF20_1.txt was closed!")

# КРОК 2: читання TF20_1 та запис найдовших слів у TF20_2
file_1_r = Open(file1_name, "r")
file_2_w = Open(file2_name, "w")

if file_1_r != None and file_2_w != None:

    text = file_1_r.read()

    # видалення розділових знаків
    for ch in string.punctuation:
        text = text.replace(ch, "")

    words = text.split()

    max_len = 0
    for word in words:
        if len(word) > max_len:
            max_len = len(word)

    for word in words:
        if len(word) == max_len:
            file_2_w.write(word + " ")

    file_1_r.close()
    file_2_w.close()
    print("Files TF20_1.txt and TF20_2.txt were closed!")

# КРОК 3: читання TF20_2 і виведення по 5 слів у рядок
print("\nResult (5 words per line):")

file_2_r = Open(file2_name, "r")

if file_2_r != None:
    words = file_2_r.read().split()

    count = 0
    for word in words:
        print(word, end=" ")
        count += 1
        if count == 5:
            print()
            count = 0

    file_2_r.close()
    print("\nFile TF20_2.txt was closed!")
