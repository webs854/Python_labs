# Варіант - 17
import math
from mod import product


def expression (m):

    z = 1/(math.sqrt(m) + math.sqrt(2))

    return z

m = int(input("Введіть значення m: "))

print ("Значення виразу z = ", expression(m))

n = int(input("Введіть значення n: "))

if product(n):
    print(f"{n} є простим")

else:
    print(f"{n} не є простим")