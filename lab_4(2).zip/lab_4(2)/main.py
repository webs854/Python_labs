array = []

# Формування масиву
for i in range(7):
    row = []
    for j in range(7):
        if j % 2 == 0:
            row.append(1)
        else:
            row.append(0)
    array.append(row)

# Виведення масиву
print("Масив:")
for i in range(7):
    for j in range(7):
        print(array[i][j], end=" ")
    print()
