import csv
import os

while True:
    user_input = input("Введіть будь-яке значення, щоб знайти показники, які більші, ніж значення,яке ввели: ")
    try:
        indicator = float(user_input)
        break
    except ValueError:
        print("Помилка! Введіть числове значення ще раз.")

os.system("cls" if os.name == "nt" else "clear")

csv_file_path = "Inflation.csv"
filtered_file_path = "Inflation_filtered.csv"

# Перевірка існування файлу
if not os.path.isfile(csv_file_path):
    print(f"Файл {csv_file_path} не знайдено!")
    exit()

flag = False

with open(filtered_file_path, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f, delimiter=";")
    writer.writerow(["Country Name", "2016 [YR2016]"])

with open(csv_file_path, "r", encoding="utf-8") as file:
    reader = csv.DictReader(file, delimiter=",")

    for row in reader:
        try:
            value_str = row["2016 [YR2016]"].replace(",", ".").strip()
            value = float(value_str)
        except (ValueError, KeyError, AttributeError):
            continue


        if not (-50 <= value <= 100):
            continue

        if value > indicator:
            flag = True
            print(row["Country Name"], ":", value)
            with open(filtered_file_path, "a", encoding="utf-8", newline="") as f:
                writer = csv.writer(f, delimiter=";")
                writer.writerow([row["Country Name"], value])

if not flag:
    print(f"Показників, більших за {indicator}, НЕ знайдено!")
else:
    print(f"\nРезультати записані у файл: {filtered_file_path}")
