def print_all(teams):
    print("\n=== Усі команди ===")
    for name, points in teams.items():
        print(f"{name} — {points} очок")
    print()

def champion(teams):
    sorted_teams = sorted(teams.items(), key=lambda x: x[1], reverse=True)
    print("\nЧемпіон:", sorted_teams[0][0])
    print()


def top_3(teams):
    sorted_teams = sorted(teams.items(), key=lambda x: x[1], reverse=True)
    print("\n2 місце:", sorted_teams[1][0])
    print("3 місце:", sorted_teams[2][0])
    print()


def main():
    teams = {
        "Динамо": 45,
        "Шахтар": 52,
        "Зоря": 38,
        "Дніпро-1": 41,
        "Олександрія": 33,
        "Ворскла": 29,
        "Колос": 24,
        "Верес": 19,
        "Металіст": 27,
        "Чорноморець": 22
    }

    while True:
        print("""
=== МЕНЮ ===
1 -> Вивести всі команди
2 -> Визначити чемпіона
3 -> Визначити 2 і 3 місце
""")

        choice = input("Введіть пункт меню: ")

        if choice == "1":
            print_all(teams)
        elif choice == "2":
            champion(teams)
        elif choice == "3":
            top_3(teams)
        else:
            print("Невірний пункт меню.")


main()