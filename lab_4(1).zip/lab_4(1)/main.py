#ЗАВДАННЯ 1: ОДНОВИМІРНИЙ МАСИВ

# Введення кількості елементів
n = int(input("Введіть кількість елементів у масиві: "))
while n <= 0:
    n = int(input("Кількість повинна бути більше 0. Введіть ще раз: "))

# Введення елементів масиву
arr = []
print(f"Введіть {n} дійсних чисел:")

i = 0
while i < n:
    value = float(input(f"Елемент {i + 1}: "))
    arr.append(value)
    i += 1

print("Ваш масив:", arr)
# Непарні елементи за індексом
odd_elements = []
i = 0
while i < len(arr):
    if i % 2 == 1:
        odd_elements.append(arr[i])
    i += 1

if len(odd_elements) > 0:
    average_odd = sum(odd_elements) / len(odd_elements)
    print("Непарні елементи (за індексом):", odd_elements)
    print(f"Середнє арифметичне: {average_odd:.2f}")
else:
    print("Непарних елементів (за індексом) немає")

# Від'ємні елементи
negative_elements = []
i = 0
while i < len(arr):
    if arr[i] < 0:
        negative_elements.append(arr[i])
    i += 1

if len(negative_elements) > 0:
    reversed_negatives = negative_elements[::-1]
    print("Від'ємні елементи:", negative_elements)
    print("Від'ємні елементи у зворотному порядку:", reversed_negatives)
else:
    print("Від'ємних елементів немає")
