t = input("Enter any string: ")

if len(t) < 2:
    print("The word is too short for the operation:")
else:
    # беремо всі символи від початку до передостаннього (t[:-1]) і перевертаємо ([::-1])
    result = t[:-1][::-1]
    print("Result:", result)
